// 1. FIREBASE CONFIGURATION
const firebaseConfig = {
    apiKey: "AIzaSyCQjMADu4M4Fp-QWe__vl1eEAAfZxHftP8",
    authDomain: "adcom-database.firebaseapp.com",
    databaseURL: "https://adcom-database-default-rtdb.firebaseio.com",
    projectId: "adcom-database",
    storageBucket: "adcom-database.firebasestorage.app",
    messagingSenderId: "44119990641",
    appId: "1:44119990641:web:c0a08877a70e5c387c16d0",
    measurementId: "G-583ZZT6JV7"
  };
  
  // Initialize Firebase
  if (!firebase.apps.length) {
      firebase.initializeApp(firebaseConfig);
  }
  const db = firebase.database();
  
  // --- OGAANSHADA INTERNET-KA (ONLINE / OFFLINE) ---
  db.ref('.info/connected').on('value', function(snap) {
    if (snap.val() === true) {
      console.log("Internet-ku waa Live (Online)");
    } else {
      console.log("Internet-ku waa ka go'an yahay (Offline) - Xogta mobaylka ayay ku kaydsan tahay");
    }
  });
  
  document.addEventListener('DOMContentLoaded', function () {
      setupLogin();
      setupFormListeners();
      listenToRealtimeData();
      registerServiceWorker();
  });
  
  // 2. REGISTER SERVICE WORKER (PWA)
  function registerServiceWorker() {
      if ('serviceWorker' in navigator) {
          navigator.serviceWorker.register('./sw.js')
              .then(() => console.log('Service Worker Registered'))
              .catch(err => console.log('SW Error:', err));
      }
  }
  
  // 3. AUTHENTICATION
  function setupLogin() {
      const loginForm = document.getElementById('loginForm');
      const loginModal = document.getElementById('loginModal');
  
      if (loginForm) {
          loginForm.addEventListener('submit', function (e) {
              e.preventDefault();
              const usernameInput = document.getElementById('username').value.trim();
              const passwordInput = document.getElementById('password').value.trim();
  
              if (usernameInput === 'admin' && passwordInput === '1234') {
                  if (loginModal) loginModal.style.display = 'none';
              } else {
                  alert('Username ama Password khaldan!');
              }
          });
      }
  }
  
  function logout() {
      const loginModal = document.getElementById('loginModal');
      if (loginModal) loginModal.style.display = 'flex';
      document.getElementById('username').value = '';
      document.getElementById('password').value = '';
  }
  
  // 4. NAVIGATION
  function showPage(pageId) {
      document.querySelectorAll('.page-section').forEach(sec => sec.classList.remove('active'));
      document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
  
      const targetSection = document.getElementById(pageId);
      if (targetSection) targetSection.classList.add('active');
  }
  
  // 5. FORM SUBMISSIONS TO FIREBASE
  function setupFormListeners() {
      // Production
      handleFormSubmit('formProduction', 'production', () => {
          const dust = parseFloat(document.getElementById('prodDust')?.value) || 0;
          const agg10 = parseFloat(document.getElementById('prodAggregate10')?.value) || 0;
          const agg20 = parseFloat(document.getElementById('prodAggregate20')?.value) || 0;
          const date = document.getElementById('prodDate')?.value || new Date().toISOString().split('T')[0];
          return {
              date, type: 'production',
              info: `Dust: ${dust}, 10mm: ${agg10}, 20mm: ${agg20}`,
              value: dust + agg10 + agg20
          };
      });
  
      // Fuel
      handleFormSubmit('formFuel', 'fuel', () => {
          const driver = document.getElementById('fuelDriverName')?.value || '';
          const plate = document.getElementById('fuelPlateNumber')?.value || '';
          const liters = parseFloat(document.getElementById('fuelLiters')?.value) || 0;
          const station = document.getElementById('fuelStationName')?.value || '';
          const date = document.getElementById('fuelDate')?.value || new Date().toISOString().split('T')[0];
          return {
              date, type: 'fuel',
              info: `Driver: ${driver} | Plate: ${plate} | Station: ${station}`,
              value: liters
          };
      });
  
      // Trucks
      handleFormSubmit('formTrucks', 'trucks', () => {
          const driver = document.getElementById('truckDriverName')?.value || '';
          const dest = document.getElementById('truckDestination')?.value || '';
          const plate = document.getElementById('truckPlateNumber')?.value || '';
          const date = document.getElementById('truckDate')?.value || new Date().toISOString().split('T')[0];
          return {
              date, type: 'trucks',
              info: `Driver: ${driver} | Dest: ${dest} | Plate: ${plate}`,
              value: 1
          };
      });
  
      // Sales
      handleFormSubmit('formSales', 'sales', () => {
          const driver = document.getElementById('salesDriverName')?.value || '';
          const customer = document.getElementById('salesCustomerName')?.value || '';
          const loads = document.getElementById('salesLoads')?.value || 0;
          const truck = document.getElementById('salesTruckInfo')?.value || '';
          const amount = parseFloat(document.getElementById('salesAmount')?.value) || 0;
          const date = document.getElementById('salesDate')?.value || new Date().toISOString().split('T')[0];
          return {
              date, type: 'sales',
              info: `Customer: ${customer} | Driver: ${driver} | Truck: ${truck} (${loads} loads)`,
              value: amount
          };
      });
  
      // Expenses
      handleFormSubmit('formExpenses', 'expenses', () => {
          const item = document.getElementById('expItemName')?.value || '';
          const amount = parseFloat(document.getElementById('expAmount')?.value) || 0;
          const loc = document.getElementById('expLocation')?.value || '';
          const date = document.getElementById('expDate')?.value || new Date().toISOString().split('T')[0];
          return {
              date, type: 'expenses',
              info: `Item: ${item} | Location: ${loc}`,
              value: amount
          };
      });
  
      // Incoming
      handleFormSubmit('formIncoming', 'incoming', () => {
          const desc = document.getElementById('incDescription')?.value || '';
          const payer = document.getElementById('incPayerName')?.value || '';
          const amount = parseFloat(document.getElementById('incAmount')?.value) || 0;
          const date = document.getElementById('incDate')?.value || new Date().toISOString().split('T')[0];
          return {
              date, type: 'incoming',
              info: `Payer: ${payer} | Desc: ${desc}`,
              value: amount
          };
      });
  }
  
  function handleFormSubmit(formId, pathKey, dataMapper) {
      const form = document.getElementById(formId);
      if (!form) return;
  
      form.addEventListener('submit', function (e) {
          e.preventDefault();
          const newItem = dataMapper();
  
          db.ref('records').push(newItem)
              .then(() => {
                  alert('Xogta si guul leh ayaa loogu kaydiyay Database-ka!');
                  form.reset();
              })
              .catch(err => {
                  alert('Cillad ayaa dhacday: ' + err.message);
              });
      });
  }
  
  // 6. REAL-TIME DATA LISTENER & REPORT RENDERER
  let cachedRecords = [];
  
  function listenToRealtimeData() {
      db.ref('records').on('value', (snapshot) => {
          const data = snapshot.val();
          cachedRecords = [];
  
          if (data) {
              Object.keys(data).forEach(key => {
                  cachedRecords.push({ id: key, ...data[key] });
              });
          }
  
          updateDashboard(cachedRecords);
          renderReports();
      });
  }
  
  // 7. DASHBOARD CALCULATIONS
  function updateDashboard(records) {
      const getSum = (type) => records.filter(r => r.type === type).reduce((sum, r) => sum + (parseFloat(r.value) || 0), 0);
      const getCount = (type) => records.filter(r => r.type === type).length;
  
      if (document.getElementById('dashTotalSales')) document.getElementById('dashTotalSales').textContent = `$${getSum('sales')}`;
      if (document.getElementById('dashTotalExpenses')) document.getElementById('dashTotalExpenses').textContent = `$${getSum('expenses')}`;
      if (document.getElementById('dashTotalIncoming')) document.getElementById('dashTotalIncoming').textContent = `$${getSum('incoming')}`;
      if (document.getElementById('dashTotalFuel')) document.getElementById('dashTotalFuel').textContent = `${getSum('fuel')} L`;
      if (document.getElementById('dashTotalTrucks')) document.getElementById('dashTotalTrucks').textContent = `${getCount('trucks')}`;
      if (document.getElementById('dashTotalProduction')) document.getElementById('dashTotalProduction').textContent = `${getSum('production')} Loads`;
  }
  
  // 8. RENDER REPORTS WITH DELETE OPTION
  function renderReports() {
      const tableBody = document.getElementById('reportTableBody');
      const filterSelect = document.getElementById('reportFilter');
      if (!tableBody) return;
  
      const tableHeader = tableBody.closest('table').querySelector('thead tr');
      if (tableHeader && tableHeader.children.length === 4) {
          const actionTh = document.createElement('th');
          actionTh.textContent = 'Action';
          tableHeader.appendChild(actionTh);
      }
  
      tableBody.innerHTML = '';
      const filterValue = filterSelect ? filterSelect.value.toLowerCase() : 'all';
  
      const filteredRecords = cachedRecords.filter(item => {
          if (filterValue === 'all') return true;
          return item.type === filterValue;
      });
  
      if (filteredRecords.length === 0) {
          tableBody.innerHTML = '<tr><td colspan="5" style="text-align:center;">Xog ma jirto.</td></tr>';
          return;
      }
  
      filteredRecords.forEach(record => {
          const row = document.createElement('tr');
          
          let unit = '';
          if (record.type === 'sales' || record.type === 'expenses' || record.type === 'incoming') {
              unit = '$';
          } else if (record.type === 'fuel') {
              unit = 'L ';
          }
  
          row.innerHTML = `
              <td>${record.date || 'N/A'}</td>
              <td style="text-transform: capitalize; font-weight: bold;">${record.type}</td>
              <td>${record.info || ''}</td>
              <td>${unit}${record.value}</td>
              <td>
                  <button style="background-color: #ef4444; color: white; border: none; padding: 5px 10px; border-radius: 4px; cursor: pointer;" onclick="deleteRecord('${record.id}')">🗑️ Delete</button>
              </td>
          `;
          tableBody.appendChild(row);
      });
  }
  
  // 9. DELETE FUNCTION
  function deleteRecord(id) {
      if (confirm("Ma ziidtaa inaad tirtirto xogtan?")) {
          db.ref('records/' + id).remove()
              .then(() => {
                  alert("Xogta waa la tirtiray!");
              })
              .catch((error) => {
                  alert("Cillad ayaa dhacday: " + error.message);
              });
      }
  }
  
  // Filter Listener
  document.addEventListener('change', function (e) {
      if (e.target && e.target.id === 'reportFilter') {
          renderReports();
      }
  });